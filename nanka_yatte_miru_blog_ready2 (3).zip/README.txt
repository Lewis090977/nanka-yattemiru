「なんか訳してみる」記事追加しやすい版

重要：
ZIPをダブルクリックして中のHTMLを直接開く場合でも、
デザインが表示されるようCSSを各HTMLに埋め込んであります。

通常はZIPを展開してから index.html を開くのがおすすめです。

構成：
index.html → トップ
articles/index.html → 記事一覧
articles/001.html → 第1回
style.css → デザイン（今後の編集用）
